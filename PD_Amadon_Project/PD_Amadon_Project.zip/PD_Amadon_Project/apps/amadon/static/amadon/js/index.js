/**
 * 
 */

$(document).ready(function()
	{
	  $("tr:even").css("background-color", "#ffcccc");
});